# UI/UX Polish

- `GUI・OS別デザインガイドライン辞書` の最初の画面で問題、差別化、次アクションを確認できる。
- 入力ミスは error、未確定は warning として分ける。
- 手動テストでは preview UI と CLI レポートの文言差分を確認する。
